import {
  renderTags,
  escapeHtml,
  formatDisplayDate,
  cardImageSrc,
  fallbackCover,
  getContentRoot,
  getQueryVariable,
  sanitizeUrl,
  sanitizeImageUrl
} from '../../../js/utils.js';
import {
  mountThemeControls,
  applySavedTheme,
  bindThemeToggle,
  bindThemePackPicker,
  bindPostEditor,
  refreshLanguageSelector,
  getSavedThemePack
} from '../../../js/theme.js';
import { hydratePostImages, hydratePostVideos, applyLazyLoadingIn, hydrateCardCovers } from '../../../js/post-render.js';
import { renderPostMetaCard, renderOutdatedCard } from '../../../js/templates.js';
import { attachHoverTooltip } from '../../../js/tags.js';
import { prefersReducedMotion } from '../../../js/dom-utils.js';
import { renderPressPostCardHtml } from '../../../js/post-card-html.js';
import { siteFeatureContextEnabled } from '../../../js/site-features.js';

const defaultWindow = typeof window !== 'undefined' ? window : undefined;
const defaultDocument = typeof document !== 'undefined' ? document : undefined;

const CLASS_HIDDEN = 'is-hidden';

let themeI18n = null;
let currentSiteConfig = null;
let activeRegions = null;
let activeThemeContext = null;

function setThemeI18n(context = {}) {
  themeI18n = context && context.i18n && typeof context.i18n === 'object' ? context.i18n : null;
  activeRegions = context && context.regions && typeof context.regions === 'object' ? context.regions : null;
  activeThemeContext = context && typeof context === 'object' ? context : null;
}

function featureEnabled(params = {}, key) {
  const features = (params && params.features)
    || (params && params.ctx && params.ctx.features)
    || (params && params.context && params.context.features)
    || (activeThemeContext && activeThemeContext.features);
  return siteFeatureContextEnabled(features, key);
}

function getRouter(params = {}) {
  return (params && params.ctx && params.ctx.router)
    || (params && params.context && params.context.router)
    || (activeThemeContext && activeThemeContext.router)
    || {};
}

function routerFunction(params = {}, name) {
  const router = getRouter(params);
  return router && typeof router[name] === 'function' ? router[name].bind(router) : null;
}

function setChromeHidden(element, hidden) {
  if (!element) return;
  try { element.hidden = !!hidden; } catch (_) {}
  try {
    if (hidden) element.setAttribute('aria-hidden', 'true');
    else element.removeAttribute('aria-hidden');
  } catch (_) {}
}

function setHomeLinkHref(link, href) {
  if (!link) return;
  if (!href) {
    try { link.removeAttribute('href'); } catch (_) {}
    try { link.setAttribute('aria-disabled', 'true'); } catch (_) {}
    try { link.setAttribute('tabindex', '-1'); } catch (_) {}
    return;
  }
  try { link.setAttribute('href', href); } catch (_) {}
  try { link.removeAttribute('aria-disabled'); } catch (_) {}
  try { link.removeAttribute('tabindex'); } catch (_) {}
}

function updateHomeLinks(documentRef = defaultDocument, params = {}) {
  if (!documentRef || typeof documentRef.querySelectorAll !== 'function') return false;
  const href = getRouteHref(params, 'getHomeHref');
  documentRef.querySelectorAll('[data-site-home]').forEach((link) => {
    setHomeLinkHref(link, href);
  });
  return !!href;
}

function getRouteHref(params = {}, name, ...args) {
  const helper = routerFunction(params, name);
  if (!helper) return null;
  try {
    const href = helper(...args);
    return href ? String(href) : null;
  } catch (_) {
    return null;
  }
}

function getRegion(name, documentRef = defaultDocument) {
  const key = String(name || '').trim();
  if (!key) return null;
  try {
    if (activeRegions && typeof activeRegions.get === 'function') {
      const region = activeRegions.get(key);
      if (region) return region;
    }
  } catch (_) {}
  try {
    if (activeRegions && activeRegions[key]) return activeRegions[key];
  } catch (_) {}
  if (!documentRef || typeof documentRef.querySelector !== 'function') return null;
  try {
    return documentRef.querySelector(`[data-theme-region="${key}"]`);
  } catch (_) {
    return null;
  }
}

function getMainRegion(documentRef = defaultDocument) {
  if (activeRegions && activeRegions.main && activeRegions.main.nodeType === 1) return activeRegions.main;
  if (documentRef && documentRef.querySelector) {
    const explicit = documentRef.querySelector('.solstice-mainview');
    if (explicit) return explicit;
  }
  const region = getRegion('main', documentRef);
  if (!region) return null;
  try {
    if (region.matches && region.matches('.solstice-mainview')) return region;
  } catch (_) {}
  return null;
}

function getTocRegion(documentRef = defaultDocument) {
  return getRegion('toc', documentRef) || (documentRef && documentRef.querySelector && documentRef.querySelector('.solstice-toc')) || null;
}

function getNavRegion(documentRef = defaultDocument) {
  return getRegion('nav', documentRef) || (documentRef && documentRef.querySelector && documentRef.querySelector('.solstice-nav')) || null;
}

function getTagsRegion(documentRef = defaultDocument) {
  return getRegion('tags', documentRef) || (documentRef && documentRef.querySelector && documentRef.querySelector('.solstice-tagband')) || null;
}

function getSearchRegion(documentRef = defaultDocument) {
  return getRegion('search', documentRef) || (documentRef && documentRef.querySelector && documentRef.querySelector('press-search.solstice-footer__search, press-search')) || null;
}

function getSearchInput(documentRef = defaultDocument) {
  const search = getSearchRegion(documentRef);
  return (search && search.input) || (search && search.querySelector && search.querySelector('input[type="search"]')) || null;
}

function getCurrentLang() {
  const i18n = themeI18n || {};
  try {
    if (typeof i18n.getCurrentLang === 'function') return i18n.getCurrentLang();
    if (typeof i18n.lang === 'string' && i18n.lang.trim()) return i18n.lang.trim();
  } catch (_) {}
  try {
    const lang = defaultDocument && defaultDocument.documentElement && defaultDocument.documentElement.getAttribute('lang');
    if (lang) return lang;
  } catch (_) {}
  try {
    const url = new URL((defaultWindow && defaultWindow.location && defaultWindow.location.href) || '');
    const lang = url.searchParams.get('lang');
    if (lang) return lang;
  } catch (_) {}
  return 'en';
}

function t(key, ...args) {
  const i18n = themeI18n || {};
  try {
    if (typeof i18n.t === 'function') return i18n.t(key, ...args);
  } catch (_) {}
  return args.length ? `${key} ${args.join(' ')}` : String(key || '');
}

function withLangParam(urlStr) {
  const i18n = themeI18n || {};
  try {
    if (typeof i18n.withLangParam === 'function') return i18n.withLangParam(urlStr);
  } catch (_) {}
  const raw = String(urlStr || '');
  const lang = getCurrentLang();
  try {
    const win = defaultWindow;
    const current = new URL((win && win.location && win.location.href) || 'https://example.test/');
    const url = new URL(raw, current.href);
    if (lang) url.searchParams.set('lang', lang);
    if (url.origin === current.origin && url.pathname === current.pathname) return `${url.search}${url.hash}`;
    return `${url.pathname}${url.search}${url.hash}`;
  } catch (_) {
    if (!lang) return raw;
    const joiner = raw.includes('?') ? '&' : '?';
    return `${raw}${joiner}lang=${encodeURIComponent(lang)}`;
  }
}

const SOLSTICE_CARD_CLASSES = {
  cardClass: 'solstice-card',
  withCoverClass: 'solstice-card--with-cover',
  linkClass: 'solstice-card__link',
  bodyClass: 'solstice-card__body',
  titleClass: 'solstice-card__title',
  excerptClass: 'solstice-card__excerpt',
  metaClass: 'solstice-card__meta',
  dateClass: 'solstice-card__meta-date',
  tagsClass: 'solstice-card__tags',
  metaPosition: 'after-title'
};

function scrollViewportToTop(documentRef = defaultDocument, windowRef = defaultWindow) {
  const behavior = prefersReducedMotion() ? 'auto' : 'smooth';
  try {
    if (windowRef && typeof windowRef.scrollTo === 'function') {
      windowRef.scrollTo({ top: 0, left: 0, behavior });
      return true;
    }
  } catch (_) { /* fall through to legacy handling */ }
  try {
    if (windowRef && typeof windowRef.scrollTo === 'function') {
      windowRef.scrollTo(0, 0);
      return true;
    }
  } catch (_) { /* fall through to DOM fallback */ }
  try {
    if (documentRef) {
      if (documentRef.documentElement) documentRef.documentElement.scrollTop = 0;
      if (documentRef.body) documentRef.body.scrollTop = 0;
      return true;
    }
  } catch (_) { /* no-op */ }
  return false;
}

function getScrollState(documentRef = defaultDocument, windowRef = defaultWindow) {
  try {
    return {
      top: Math.max(0, Math.round(windowRef && typeof windowRef.scrollY === 'number'
        ? windowRef.scrollY
        : ((documentRef && documentRef.documentElement && documentRef.documentElement.scrollTop) || 0))),
      left: Math.max(0, Math.round(windowRef && typeof windowRef.scrollX === 'number'
        ? windowRef.scrollX
        : ((documentRef && documentRef.documentElement && documentRef.documentElement.scrollLeft) || 0)))
    };
  } catch (_) {
    return { top: 0, left: 0 };
  }
}

function restoreScrollState(params = {}, documentRef = defaultDocument, windowRef = defaultWindow) {
  const top = Math.max(0, Math.round(Number(params.top) || 0));
  const left = Math.max(0, Math.round(Number(params.left) || 0));
  try {
    if (windowRef && typeof windowRef.scrollTo === 'function') {
      windowRef.scrollTo({ top, left, behavior: 'auto' });
      return true;
    }
  } catch (_) {}
  try {
    if (windowRef && typeof windowRef.scrollTo === 'function') {
      windowRef.scrollTo(left, top);
      return true;
    }
  } catch (_) {}
  try {
    if (documentRef && documentRef.documentElement) {
      documentRef.documentElement.scrollTop = top;
      documentRef.documentElement.scrollLeft = left;
    }
    if (documentRef && documentRef.body) {
      documentRef.body.scrollTop = top;
      documentRef.body.scrollLeft = left;
    }
    return true;
  } catch (_) {
    return false;
  }
}

function setupDynamicBackground(documentRef = defaultDocument, windowRef = defaultWindow) {
  const root = documentRef && documentRef.querySelector ? documentRef.querySelector('.solstice-shell') : null;
  if (!root) return false;

  if (typeof prefersReducedMotion === 'function' && prefersReducedMotion()) {
    root.style.setProperty('--solstice-scroll-offset', '0px');
    root.style.setProperty('--solstice-scroll-tilt', '0deg');
    return false;
  }

  let frame = null;

  const readScrollPosition = () => {
    frame = null;
    let scrollY = 0;
    if (windowRef && typeof windowRef.scrollY === 'number') {
      scrollY = windowRef.scrollY;
    } else if (documentRef && documentRef.documentElement) {
      scrollY = documentRef.documentElement.scrollTop || 0;
    }
    const clampedOffset = Math.max(-800, Math.min(1600, scrollY));
    const tilt = Math.max(-6, Math.min(10, clampedOffset * 0.01));
    root.style.setProperty('--solstice-scroll-offset', `${clampedOffset}px`);
    root.style.setProperty('--solstice-scroll-tilt', `${tilt}deg`);
  };

  const queueUpdate = () => {
    if (frame != null) return;
    if (windowRef && typeof windowRef.requestAnimationFrame === 'function') {
      frame = windowRef.requestAnimationFrame(readScrollPosition);
    } else {
      frame = setTimeout(readScrollPosition, 16);
    }
  };

  readScrollPosition();
  queueUpdate();

  if (windowRef && typeof windowRef.addEventListener === 'function') {
    windowRef.addEventListener('scroll', queueUpdate, { passive: true });
    windowRef.addEventListener('resize', queueUpdate);
  }

  return true;
}

function resolveCoverSource(meta = {}, siteConfig = {}) {
  const allowFallback = !(siteConfig && siteConfig.cardCoverFallback === false);
  if (!meta) return { coverSrc: '', allowFallback };

  const preferred = meta.thumb || meta.cover || meta.image;
  let coverSrc = '';
  if (typeof preferred === 'string') {
    coverSrc = preferred.trim();
  } else if (preferred && typeof preferred === 'object') {
    const maybeString = preferred.src || preferred.url || '';
    coverSrc = typeof maybeString === 'string' ? maybeString.trim() : '';
  }

  if (coverSrc) {
    const isProtocolRelative = coverSrc.startsWith('//');
    const hasScheme = /^[a-z][a-z0-9+.-]*:/i.test(coverSrc);
    if (!hasScheme && !isProtocolRelative && !coverSrc.startsWith('/') && !coverSrc.startsWith('#')) {
      const hasDirectorySegment = coverSrc.includes('/');
      const isDotRelative = coverSrc.startsWith('./') || coverSrc.startsWith('../');
      if (isDotRelative || !hasDirectorySegment) {
        const baseLoc = meta && meta.location ? String(meta.location) : '';
        const lastSlash = baseLoc.lastIndexOf('/');
        const baseDir = lastSlash >= 0 ? baseLoc.slice(0, lastSlash + 1) : '';
        if (isDotRelative) {
          try {
            const resolved = new URL(coverSrc, `https://example.invalid/${baseDir}`);
            coverSrc = resolved.pathname.replace(/^\/+/, '');
          } catch (_) {
            coverSrc = `${baseDir}${coverSrc}`.replace(/\/+/g, '/');
          }
        } else {
          coverSrc = `${baseDir}${coverSrc}`.replace(/\/+/g, '/');
        }
      }
    }
    const root = typeof getContentRoot === 'function' ? getContentRoot() : '';
    const normalizedRoot = String(root || '').replace(/^\/+|\/+$/g, '');
    if (normalizedRoot && coverSrc.startsWith(`${normalizedRoot}/`)) {
      coverSrc = coverSrc.slice(normalizedRoot.length + 1);
    }
    const safeSrc = sanitizeImageUrl ? sanitizeImageUrl(coverSrc) : coverSrc;
    if (safeSrc) {
      return { coverSrc: safeSrc, allowFallback };
    }
  }

  return { coverSrc: '', allowFallback };
}

function applySolsticeCoverClass(markup) {
  if (!markup) return '';
  if (markup.includes('solstice-card__cover')) return markup;
  if (markup.includes('card-cover-wrap')) {
    return markup.replace('card-cover-wrap', 'card-cover-wrap solstice-card__cover');
  }
  return `<div class="solstice-card__cover">${markup}</div>`;
}

function normalizeCoverUrl(coverSrc) {
  if (!coverSrc) return '';
  if (/^(?:https?:|data:|blob:)/i.test(coverSrc)) return coverSrc;
  return cardImageSrc(coverSrc);
}

function renderCardCover(meta, title, siteConfig) {
  const heading = typeof title === 'string' ? title : '';
  const { coverSrc, allowFallback } = resolveCoverSource(meta, siteConfig);
  if (coverSrc) {
    const resolved = normalizeCoverUrl(coverSrc);
    if (resolved) {
      const alt = meta && meta.coverAlt ? meta.coverAlt : heading;
      return `<div class="solstice-card__cover card-cover-wrap"><span class="ph-skeleton" aria-hidden="true"></span><img class="card-cover" src="${escapeHtml(resolved)}" alt="${escapeHtml(String(alt || ''))}" loading="lazy" decoding="async" fetchpriority="low" /></div>`;
    }
  }
  if (allowFallback) {
    const fallback = fallbackCover(heading);
    return applySolsticeCoverClass(fallback);
  }
  return '';
}

function renderHeroImage(meta, title, siteConfig) {
  const heading = typeof title === 'string' ? title : '';
  const { coverSrc } = resolveCoverSource(meta, siteConfig);
  if (!coverSrc) return '';
  const resolved = normalizeCoverUrl(coverSrc);
  if (!resolved) return '';
  const alt = meta && meta.coverAlt ? meta.coverAlt : heading;
  return `<div class="solstice-article__hero"><img src="${escapeHtml(resolved)}" alt="${escapeHtml(String(alt || ''))}" loading="lazy" decoding="async" /></div>`;
}

function localized(cfg, key) {
  if (!cfg) return '';
  const val = cfg[key];
  if (!val) return '';
  if (typeof val === 'string') return val;
  const lang = getCurrentLang && getCurrentLang();
  if (lang && val[lang]) return val[lang];
  return val.default || '';
}

function getRoleElement(role, documentRef = defaultDocument) {
  if (!documentRef) return null;
  switch (role) {
    case 'main':
      return getMainRegion(documentRef);
    case 'toc':
      return getTocRegion(documentRef);
    case 'sidebar':
      return getTagsRegion(documentRef);
    case 'content':
      return getRegion('content', documentRef) || documentRef.querySelector('.solstice-main');
    case 'container':
      return getRegion('container', documentRef) || documentRef.querySelector('.solstice-shell');
    default:
      return null;
  }
}

function fadeIn(element) {
  if (!element) return;
  element.classList.remove(CLASS_HIDDEN);
  element.hidden = false;
  element.style.removeProperty('display');
  requestAnimationFrame(() => {
    element.classList.add('is-visible');
  });
}

function fadeOut(element, onDone) {
  if (!element) { if (typeof onDone === 'function') onDone(); return; }
  element.classList.remove('is-visible');
  const finish = () => {
    element.classList.add(CLASS_HIDDEN);
    element.hidden = true;
    if (typeof onDone === 'function') onDone();
  };
  if (prefersReducedMotion()) {
    finish();
  } else {
    element.addEventListener('transitionend', finish, { once: true });
    const timer = setTimeout(finish, 320);
    element.addEventListener('transitioncancel', () => clearTimeout(timer), { once: true });
  }
}

function buildCard({ title, meta, translate, link, siteConfig, features }) {
  if (!link) return '';
  const excerpt = meta && meta.excerpt ? String(meta.excerpt) : '';
  const showPostMeta = featureEnabled({ features }, 'postMeta');
  const date = showPostMeta && meta && meta.date ? formatDisplayDate(meta.date) : '';
  const showTags = featureEnabled({ features }, 'tags') && featureEnabled({ features }, 'search');
  const tags = showTags && meta ? renderTags(meta.tag) : '';
  const coverHtml = renderCardCover(meta, title, siteConfig);
  return renderPressPostCardHtml({
    title: String(title || 'Untitled'),
    href: link,
    date,
    excerpt,
    coverHtml,
    tagsHtml: tags,
    classes: SOLSTICE_CARD_CLASSES
  });
}

function ensureSolsticeExcerptNode(card, documentRef = defaultDocument) {
  if (!card || !documentRef) return null;
  let excerptEl = card.querySelector('.solstice-card__excerpt');
  if (!excerptEl) {
    const body = card.querySelector('.solstice-card__body');
    if (!body) return null;
    excerptEl = documentRef.createElement('p');
    excerptEl.className = 'solstice-card__excerpt';
    body.appendChild(excerptEl);
  }
  return excerptEl;
}

function hydrateSolsticeCardExcerpts(entries = [], context = {}) {
  const documentRef = context.document || defaultDocument;
  if (!documentRef) return;
  const root = context.container || documentRef;
  const cards = Array.from(root.querySelectorAll('.solstice-card'));
  const getFile = typeof context.getFile === 'function' ? context.getFile : null;
  const getContentRoot = typeof context.getContentRoot === 'function' ? context.getContentRoot : null;
  const extractExcerpt = typeof context.extractExcerpt === 'function' ? context.extractExcerpt : null;

  entries.forEach(([title, meta], idx) => {
    const card = cards[idx];
    if (!card) return;
    const preset = meta && meta.excerpt ? String(meta.excerpt) : '';
    if (preset) {
      const node = ensureSolsticeExcerptNode(card, documentRef);
      if (node) node.textContent = preset;
      card.dataset.solsticeExcerptHydrated = '1';
      return;
    }

    if (card.dataset.solsticeExcerptHydrated === 'pending' || card.dataset.solsticeExcerptHydrated === '1') return;

    const loc = meta && meta.location ? String(meta.location) : '';
    if (!loc || !getFile || !getContentRoot || !extractExcerpt) return;

    card.dataset.solsticeExcerptHydrated = 'pending';
    getFile(`${getContentRoot()}/${loc}`).then(md => {
      const text = String(extractExcerpt(md, 50) || '').trim();
      if (!text) { delete card.dataset.solsticeExcerptHydrated; return; }
      const node = ensureSolsticeExcerptNode(card, documentRef);
      if (node) {
        node.textContent = text;
        card.dataset.solsticeExcerptHydrated = '1';
      } else {
        delete card.dataset.solsticeExcerptHydrated;
      }
    }).catch(() => {
      delete card.dataset.solsticeExcerptHydrated;
    });
  });
}

function filterEntriesWithPostHref(entries = [], context = {}) {
  return (Array.isArray(entries) ? entries : []).filter(([, meta]) => {
    const location = meta && meta.location ? String(meta.location) : '';
    return !!(location && getRouteHref(context, 'getPostHref', location));
  });
}

function buildPagination({ page, totalPages, makeHref }) {
  if (!totalPages || totalPages <= 1) return '';
  const mkHref = (p) => {
    if (typeof makeHref !== 'function') return '';
    try {
      const href = makeHref(p);
      return href ? String(href) : '';
    } catch (_) { return ''; }
  };
  const items = [];
  const renderPageControl = (href, label, cls = '') => {
    const text = escapeHtml(String(label || ''));
    const className = String(cls || '').trim();
    return href
      ? `<a class="${className}" href="${escapeHtml(href)}">${text}</a>`
      : `<span class="${`${className} is-disabled`.trim()}" aria-disabled="true">${text}</span>`;
  };
  for (let i = 1; i <= totalPages; i++) {
    const href = mkHref(i);
    items.push(renderPageControl(href, String(i), `solstice-page${i === page ? ' is-current' : ''}`));
  }
  const prevHref = page > 1 ? mkHref(page - 1) : '';
  const nextHref = page < totalPages ? mkHref(page + 1) : '';
  return `<nav class="solstice-pagination" aria-label="${t('ui.pagination')}">
    ${renderPageControl(prevHref, t('ui.prev'), 'solstice-page prev')}
    <div class="solstice-page__list">${items.join('')}</div>
    ${renderPageControl(nextHref, t('ui.next'), 'solstice-page next')}
  </nav>`;
}

function decorateArticle(container, translate, utilities, markdown, meta, title, params = {}) {
  if (!container) return;
  const copyBtn = container.querySelector('.post-meta-copy');
  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      const loc = defaultWindow && defaultWindow.location ? defaultWindow.location.href : (typeof location !== 'undefined' ? location.href : '');
      const href = String(loc || '').split('#')[0];
      let ok = false;
      try {
        const nav = defaultWindow && defaultWindow.navigator;
        if (nav && nav.clipboard && typeof nav.clipboard.writeText === 'function') {
          await nav.clipboard.writeText(href);
          ok = true;
        }
      } catch (_) {}
      if (!ok && defaultDocument && defaultDocument.execCommand) {
        const tmp = defaultDocument.createElement('textarea');
        tmp.value = href;
        defaultDocument.body.appendChild(tmp);
        tmp.select();
        ok = defaultDocument.execCommand('copy');
        defaultDocument.body.removeChild(tmp);
      }
      if (ok) {
        copyBtn.classList.add('copied');
        copyBtn.setAttribute('data-status', 'copied');
        setTimeout(() => {
          copyBtn.classList.remove('copied');
          copyBtn.removeAttribute('data-status');
        }, 1200);
      }
    });
  }

  const versionSelect = container.querySelector('.post-version-select');
  if (versionSelect) {
    versionSelect.addEventListener('change', () => {
      const target = versionSelect.value;
      if (!target) return;
      const href = getRouteHref(params, 'getPostHref', target);
      if (!href) return;
      if (defaultWindow) {
        defaultWindow.location.href = href;
      } else {
        location.href = href; // eslint-disable-line no-restricted-globals
      }
    });
  }

  const outdated = container.querySelector('.post-outdated-card');
  if (outdated) {
    const close = outdated.querySelector('.post-outdated-close');
    if (close) close.addEventListener('click', () => outdated.remove());
  }

  try {
    const aiFlags = Array.from(container.querySelectorAll('.ai-flag'));
    aiFlags.forEach(flag => attachHoverTooltip(flag, () => translate('ui.aiFlagTooltip'), { delay: 0 }));
  } catch (_) {}

  try {
    if (typeof utilities.hydratePostImages === 'function') utilities.hydratePostImages(container);
    if (typeof utilities.hydratePostVideos === 'function') utilities.hydratePostVideos(container);
    if (typeof utilities.applyLazyLoadingIn === 'function') utilities.applyLazyLoadingIn(container);
  } catch (_) {}
}

function renderNavLinks(nav, tabsBySlug, activeSlug, postsEnabled, getHomeSlug, params = {}) {
  if (!nav) return;
  const items = [];
  const getHome = routerFunction(params, 'getHomeSlug') || (typeof getHomeSlug === 'function' ? getHomeSlug : null);
  const postsEnabledFn = routerFunction(params, 'postsEnabled') || (typeof postsEnabled === 'function' ? postsEnabled : () => true);
  const homeSlug = getHome ? getHome() : 'posts';
  updateHomeLinks(nav.ownerDocument || defaultDocument, { ...params, getHomeSlug: () => homeSlug });
  const postsHref = getRouteHref(params, 'getPostsHref');
  if (postsEnabledFn() && postsHref) {
    items.push({ slug: 'posts', label: t('ui.allPosts'), href: postsHref });
  }
  Object.entries(tabsBySlug || {}).forEach(([slug, info]) => {
    const label = info && info.title ? String(info.title) : slug;
    const href = getRouteHref(params, 'getTabHref', slug);
    if (href) items.push({ slug, label, href });
  });
  nav.innerHTML = items.map(item => `<a class="solstice-nav__item${item.slug === activeSlug ? ' is-current' : ''}" data-tab="${escapeHtml(item.slug)}" href="${escapeHtml(item.href)}">${escapeHtml(item.label)}</a>`).join('');
  nav.setAttribute('data-active', activeSlug || homeSlug);
}

function renderFooterLinks(root, tabsBySlug, postsEnabled, getHomeSlug, getHomeLabel, params = {}) {
  if (!root) return;
  const host = root.closest ? root.closest('.solstice-footer__nav') || root : root;
  const column = root.closest ? root.closest('[data-footer-column="nav"]') : null;
  if (!featureEnabled(params, 'footerNav')) {
    root.innerHTML = '';
    setChromeHidden(root, true);
    setChromeHidden(host, true);
    setChromeHidden(column, true);
    return;
  }
  setChromeHidden(root, false);
  setChromeHidden(host, false);
  setChromeHidden(column, false);
  const links = [];
  const getHome = routerFunction(params, 'getHomeSlug') || getHomeSlug;
  const getLabel = routerFunction(params, 'getHomeLabel') || getHomeLabel;
  const homeSlug = typeof getHome === 'function' ? getHome() : '';
  const homeLabel = typeof getLabel === 'function' ? getLabel() : '';
  const homeHref = getRouteHref(params, 'getHomeHref');
  if (homeHref) links.push({ href: homeHref, label: homeLabel || homeSlug });
  Object.entries(tabsBySlug || {}).forEach(([slug, info]) => {
    if (slug === homeSlug) return;
    const label = info && info.title ? String(info.title) : slug;
    const href = getRouteHref(params, 'getTabHref', slug);
    if (href) links.push({ href, label });
  });
  const searchEnabledFn = routerFunction(params, 'searchEnabled');
  const searchEnabled = searchEnabledFn ? searchEnabledFn() : featureEnabled(params, 'search');
  const searchHref = getRouteHref(params, 'getSearchHref');
  if (searchEnabled && searchHref) links.push({ href: searchHref, label: t('ui.searchTab') });
  root.innerHTML = `<ul class="solstice-footer__list">${links.map(link => `<li><a href="${escapeHtml(link.href)}">${escapeHtml(link.label)}</a></li>`).join('')}</ul>`;
}

function renderLinksList(root, cfg, params = {}) {
  if (!root) return;
  const host = root.closest ? root.closest('.solstice-footer__links') : null;
  if (!featureEnabled(params, 'profileLinks')) {
    root.innerHTML = '';
    setChromeHidden(host || root, true);
    return;
  }
  setChromeHidden(host || root, false);
  const list = Array.isArray(cfg && cfg.profileLinks) ? cfg.profileLinks : [];
  if (!list.length) {
    root.innerHTML = `<li class="solstice-linklist__empty">${t('editor.site.noLinks')}</li>`;
    return;
  }
  root.innerHTML = list.map(item => {
    if (!item || !item.href) return '';
    const label = item.label || item.href;
    const href = sanitizeUrl(String(item.href));
    if (!href) return '';
    return `<li><a href="${escapeHtml(href)}" target="_blank" rel="noopener">${escapeHtml(label)}</a></li>`;
  }).join('');
}

function updateSearchPlaceholder(documentRef = defaultDocument, params = {}) {
  const search = documentRef ? getSearchRegion(documentRef) : null;
  if (!featureEnabled(params, 'search')) {
    setChromeHidden(search, true);
    return;
  }
  setChromeHidden(search, false);
  if (search && typeof search.setPlaceholder === 'function') {
    search.setPlaceholder(t('sidebar.searchPlaceholder'));
    return;
  }
  const input = documentRef ? getSearchInput(documentRef) : null;
  if (!input) return;
  input.setAttribute('placeholder', t('sidebar.searchPlaceholder'));
}

function sanitizePackValue(value) {
  return String(value || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
}

function prettifyPackLabel(value, label) {
  if (label && String(label).trim()) return String(label).trim();
  if (!value) return '';
  return value.replace(/[-_]+/g, ' ').replace(/\b([a-z])/g, (m, c) => c.toUpperCase());
}

function populateThemePackOptions(documentRef = defaultDocument, windowRef = defaultWindow) {
  const select = documentRef ? documentRef.getElementById('themePack') : null;
  if (!select || !documentRef) return false;

  const fallbackOptions = [
    { value: 'native', label: 'Native' },
    { value: 'solstice', label: 'Solstice' },
    { value: 'arcus', label: 'Arcus' },
    { value: 'cartograph', label: 'Cartograph' }
  ];

  const seen = new Set();

  const appendOption = (value, label) => {
    const sanitized = sanitizePackValue(value);
    if (!sanitized || seen.has(sanitized)) return;
    const option = documentRef.createElement('option');
    option.value = sanitized;
    option.textContent = prettifyPackLabel(sanitized, label);
    select.appendChild(option);
    seen.add(sanitized);
  };

  const ensureSavedOptionVisible = () => {
    let saved = '';
    try {
      saved = getSavedThemePack ? getSavedThemePack() : '';
    } catch (_) {
      saved = '';
    }
    const normalized = sanitizePackValue(saved) || (select.options[0] ? select.options[0].value : '');
    if (normalized && !Array.from(select.options).some(opt => opt.value === normalized)) {
      appendOption(normalized, null);
    }
    if (normalized) {
      select.value = normalized;
    } else if (select.options.length) {
      select.selectedIndex = 0;
    }
  };

  const applyOptions = (options) => {
    select.innerHTML = '';
    seen.clear();
    (options || []).forEach(item => {
      if (!item) return;
      const sourceValue = item.value != null ? item.value : (item.slug != null ? item.slug : item.name);
      appendOption(sourceValue, item.label);
    });
    if (!select.options.length) {
      fallbackOptions.forEach(item => appendOption(item.value, item.label));
    }
  };

  const fetcher = (windowRef && typeof windowRef.fetch === 'function')
    ? windowRef.fetch.bind(windowRef)
    : (typeof fetch === 'function' ? fetch : null);

  if (!fetcher) {
    applyOptions(fallbackOptions);
    ensureSavedOptionVisible();
    return true;
  }

  try {
    fetcher('assets/themes/packs.json', { cache: 'no-store' })
      .then(response => {
        if (!response || !response.ok) throw new Error('packs.json fetch failed');
        return response.json();
      })
      .then(list => {
        if (Array.isArray(list) && list.length) {
          applyOptions(list);
        } else {
          applyOptions(fallbackOptions);
        }
      })
      .catch(() => {
        applyOptions(fallbackOptions);
      })
      .finally(() => {
        ensureSavedOptionVisible();
      });
  } catch (_) {
    applyOptions(fallbackOptions);
    ensureSavedOptionVisible();
  }

  return true;
}

function setupToolsPanel(documentRef = defaultDocument, windowRef = defaultWindow, themeContext = activeThemeContext) {
  const panel = documentRef && documentRef.getElementById('toolsPanel');
  if (!panel) return false;
  const host = panel.closest ? panel.closest('.solstice-footer__tools') || panel : panel;
  if (!featureEnabled({ context: themeContext }, 'visitorThemeControls')) {
    panel.innerHTML = '';
    setChromeHidden(host, true);
    return true;
  }
  setChromeHidden(host, false);
  try { mountThemeControls({ host: panel, variant: 'solstice', themeContext }); } catch (_) {}
  try { applySavedTheme(); } catch (_) {}
  return true;
}

function resetToolsPanel(documentRef = defaultDocument, windowRef = defaultWindow, themeContext = activeThemeContext) {
  const panel = documentRef && documentRef.getElementById('toolsPanel');
  if (!panel) return false;
  panel.innerHTML = '';
  return setupToolsPanel(documentRef, windowRef, themeContext);
}

function clearSolsticeToc(tocEl) {
  if (!tocEl) return;
  if (typeof tocEl.clear === 'function') tocEl.clear();
  else tocEl.innerHTML = '';
}

function showToc(tocEl, tocHtml, articleTitle) {
  if (!tocEl) return;
  if (!tocHtml) {
    clearSolsticeToc(tocEl);
    tocEl.hidden = true;
    return;
  }
  if (typeof tocEl.renderToc === 'function') {
    tocEl.renderToc({
      articleTitle: articleTitle || t('ui.tableOfContents'),
      tocHtml,
      contentRoot: getMainRegion(tocEl.ownerDocument || defaultDocument)
    });
  } else {
    tocEl.innerHTML = `<div class="solstice-toc__inner"><div class="solstice-toc__title">${escapeHtml(articleTitle || t('ui.tableOfContents'))}</div>${tocHtml}</div>`;
  }
  tocEl.hidden = false;
  fadeIn(tocEl);
}

function renderLoader(target, message) {
  if (!target) return;
  target.innerHTML = `<div class="solstice-loader" role="status">
    <div class="solstice-loader__spinner"></div>
    <div class="solstice-loader__text">${escapeHtml(message || t('ui.loading'))}</div>
  </div>`;
}

function renderStaticView(container, title, html) {
  if (!container) return;
  const safeHtml = html != null ? html : '';
  container.innerHTML = `<article class="solstice-static">
    <header class="solstice-static__header">
      <h1>${escapeHtml(title || '')}</h1>
    </header>
    <div class="solstice-static__body">${safeHtml}</div>
  </article>`;
}

function mountHooks(documentRef = defaultDocument, windowRef = defaultWindow) {
  const hooks = {};

  hooks.resolveViewContainers = ({ view }) => {
    return {
      view,
      mainElement: getRoleElement('main', documentRef),
      tocElement: getRoleElement('toc', documentRef),
      sidebarElement: getRoleElement('sidebar', documentRef),
      contentElement: getRoleElement('content', documentRef),
      containerElement: getRoleElement('container', documentRef)
    };
  };

  hooks.getViewContainer = ({ role }) => getRoleElement(role, documentRef);
  hooks.getScrollState = () => getScrollState(documentRef, windowRef);
  hooks.restoreScrollState = (params = {}) => restoreScrollState(params, documentRef, windowRef);

  hooks.showElement = ({ element }) => fadeIn(element);
  hooks.hideElement = ({ element, onDone }) => { fadeOut(element, onDone); return true; };

  hooks.renderSiteIdentity = ({ config, ctx, getHomeSlug, features }) => {
    currentSiteConfig = config || currentSiteConfig;
    updateHomeLinks(documentRef, { ctx, getHomeSlug, features });
    const title = localized(config, 'siteTitle');
    const subtitle = localized(config, 'siteSubtitle');
    const titleEl = documentRef.querySelector('[data-site-title]');
    const subtitleEl = documentRef.querySelector('[data-site-subtitle]');
    if (titleEl) titleEl.textContent = title || 'Press';
    if (subtitleEl) subtitleEl.textContent = subtitle || '';
  };

  hooks.renderSiteLinks = ({ config, features }) => {
    const root = documentRef.querySelector('[data-site-links]');
    renderLinksList(root, config, { features });
  };

  hooks.updateLayoutLoadingState = ({ isLoading, containerElement }) => {
    const target = containerElement || getRoleElement('content', documentRef);
    if (!target) return;
    target.classList.toggle('is-loading', !!isLoading);
  };

  hooks.renderPostTOC = ({ tocElement, tocHtml, articleTitle, features }) => {
    const toc = tocElement || getRoleElement('toc', documentRef);
    if (!featureEnabled({ features }, 'toc')) {
      clearSolsticeToc(toc);
      if (toc) toc.hidden = true;
      return true;
    }
    showToc(toc, tocHtml, articleTitle);
    return true;
  };

  hooks.renderErrorState = ({ targetElement, title, message, actions }) => {
    const target = targetElement || getRoleElement('main', documentRef);
    if (!target) return false;
    const actionHtml = Array.isArray(actions) && actions.length
      ? `<div class="solstice-error__actions">${actions.map(a => `<a class="solstice-btn" href="${escapeHtml(withLangParam(a.href || '#'))}">${escapeHtml(a.label || '')}</a>`).join('')}</div>`
      : '';
    const heading = title || t('errors.pageUnavailableTitle');
    const body = message || t('errors.pageUnavailableBody');
    target.innerHTML = `<section class="solstice-error" role="alert">
      <h2>${escapeHtml(heading)}</h2>
      <p>${escapeHtml(body)}</p>
      ${actionHtml}
    </section>`;
    return true;
  };

  hooks.handleViewChange = ({ view, features }) => {
    if (!documentRef || !documentRef.body) return;
    documentRef.body.setAttribute('data-active-view', view || 'posts');
    const toc = getRoleElement('toc', documentRef);
    if (toc && view !== 'post') {
      clearSolsticeToc(toc);
      toc.hidden = true;
    }
    const search = documentRef.querySelector('press-search');
    if (!featureEnabled({ features }, 'search')) setChromeHidden(search, true);
    if (!featureEnabled({ features }, 'tags') || !featureEnabled({ features }, 'search')) {
      const tags = getTagsRegion(documentRef);
      if (tags) {
        tags.innerHTML = '';
        setChromeHidden(tags, true);
      }
    }
    const value = view === 'search' ? (getQueryVariable('q') || '') : '';
    if (search) search.value = value;
    const input = search && search.input ? search.input : getSearchInput(documentRef);
    if (input) input.value = value;
  };

  hooks.renderTagSidebar = ({ postsIndex, utilities, features }) => {
    if (!featureEnabled({ features }, 'tags') || !featureEnabled({ features }, 'search')) {
      const tags = getTagsRegion(documentRef);
      if (tags) {
        tags.innerHTML = '';
        setChromeHidden(tags, true);
      }
      return true;
    }
    setChromeHidden(getTagsRegion(documentRef), false);
    const render = utilities && typeof utilities.renderTagSidebar === 'function'
      ? utilities.renderTagSidebar
      : null;
    if (!render) {
      const tags = getTagsRegion(documentRef);
      if (tags) {
        tags.innerHTML = '';
        setChromeHidden(tags, true);
      }
      return true;
    }
    try { render(postsIndex || {}); } catch (_) {}
    return true;
  };

  hooks.enhanceIndexLayout = (params = {}) => {
    const container = params.containerElement || getRoleElement('main', documentRef);
    try { if (typeof hydrateCardCovers === 'function') hydrateCardCovers(container); } catch (_) {}
    try { if (typeof applyLazyLoadingIn === 'function') applyLazyLoadingIn(container); } catch (_) {}
    try { if (featureEnabled(params, 'search') && typeof params.setupSearch === 'function') params.setupSearch(params.allEntries || []); } catch (_) {}
    try {
      if (featureEnabled(params, 'tags') && featureEnabled(params, 'search') && typeof params.renderTagSidebar === 'function') {
        setChromeHidden(getTagsRegion(documentRef), false);
        params.renderTagSidebar(params.postsIndexMap || {});
      } else {
        const tags = getTagsRegion(documentRef);
        if (tags) {
          tags.innerHTML = '';
          setChromeHidden(tags, true);
        }
      }
    } catch (_) {}
    return true;
  };

  hooks.renderTabs = ({ tabsBySlug, activeSlug, ctx, getHomeSlug, postsEnabled, features }) => {
    const nav = getNavRegion(documentRef);
    if (!nav) return false;
    renderNavLinks(nav, tabsBySlug, activeSlug, postsEnabled, getHomeSlug, { ctx, features });
    return true;
  };

  hooks.renderFooterNav = ({ tabsBySlug, ctx, postsEnabled, getHomeSlug, getHomeLabel, features }) => {
    const footerNav = documentRef.getElementById('footerNav');
    if (!footerNav) return false;
    renderFooterLinks(footerNav, tabsBySlug, postsEnabled, getHomeSlug, getHomeLabel, { ctx, features });
    return true;
  };

  hooks.renderPostLoadingState = ({ containers }) => {
    const main = containers && containers.mainElement ? containers.mainElement : getRoleElement('main', documentRef);
    renderLoader(main, t('ui.loading'));
    return true;
  };

  hooks.renderPostView = ({ containers, markdownHtml, fallbackTitle, postMetadata, markdown, postsIndex, postId, siteConfig, translate, utilities, features, ctx }) => {
    const main = containers && containers.mainElement ? containers.mainElement : getRoleElement('main', documentRef);
    if (!main) return;
    const title = (postMetadata && postMetadata.title) || fallbackTitle || '';
    const hero = renderHeroImage(postMetadata, title, siteConfig);
    const showPostMeta = featureEnabled({ features }, 'postMeta');
    const date = showPostMeta && postMetadata && postMetadata.date ? formatDisplayDate(postMetadata.date) : '';
    const showTags = featureEnabled({ features }, 'tags') && featureEnabled({ features }, 'search');
    const tagMarkup = showTags && postMetadata ? renderTags(postMetadata.tag) : '';
    const metaCard = showPostMeta ? renderPostMetaCard(title, postMetadata || {}, markdown, { showTags }) : '';
    const outdatedCard = showPostMeta ? renderOutdatedCard(postMetadata || {}, siteConfig) : '';

    main.innerHTML = `
      <article class="solstice-article" data-post-id="${escapeHtml(postId || '')}">
        <header class="solstice-article__header">
          ${hero || ''}
          <div class="solstice-article__heading">
            ${date ? `<p class="solstice-article__meta-line">${escapeHtml(date)}</p>` : ''}
            <h1 class="solstice-article__title">${escapeHtml(title)}</h1>
            ${tagMarkup ? `<div class="solstice-article__tags">${tagMarkup}</div>` : ''}
          </div>
          <div class="solstice-article__meta">
            ${outdatedCard || ''}
            ${metaCard || ''}
          </div>
        </header>
        <div class="solstice-article__body">${markdownHtml}</div>
        <footer class="solstice-article__footer">
          <div class="solstice-article__nav" data-post-nav></div>
        </footer>
      </article>`;

    try { if (utilities && typeof utilities.renderPostNav === 'function') utilities.renderPostNav(main.querySelector('[data-post-nav]'), postsIndex || {}, postMetadata && postMetadata.location); } catch (_) {}
    decorateArticle(main, translate || t, { hydratePostImages, hydratePostVideos, applyLazyLoadingIn }, markdown, postMetadata, title, { ctx, features });
    scrollViewportToTop(documentRef, windowRef);
    return { decorated: true, title };
  };

  hooks.decoratePostView = ({ container, translate, utilities, markdown, postMetadata, articleTitle, ctx, features }) => {
    decorateArticle(container || getRoleElement('main', documentRef), translate || t, utilities || { hydratePostImages, hydratePostVideos, applyLazyLoadingIn }, markdown, postMetadata, articleTitle, { ctx, features });
    return true;
  };

  hooks.scrollToHash = ({ hash }) => {
    if (!hash) return false;
    try {
      const target = documentRef.getElementById(hash) || documentRef.querySelector(`[id='${hash}']`);
      if (!target) return false;
      target.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'start' });
      return true;
    } catch (_) { return false; }
  };

  hooks.renderIndexView = ({ container, pageEntries, page, totalPages, siteConfig, features, ctx }) => {
    if (!container) container = getRoleElement('main', documentRef);
    if (!container) return false;
    const cards = (pageEntries || []).map(([title, meta]) => {
      const href = meta && meta.location ? getRouteHref({ ctx, features }, 'getPostHref', meta.location) : '';
      return buildCard({ title, meta, translate: t, link: href, siteConfig, features });
    }).join('');
    container.innerHTML = `<div class="solstice-index index">
      <div class="solstice-index__grid">${cards || `<p class="solstice-empty">${t('ui.noResultsTitle')}</p>`}</div>
      ${buildPagination({ page, totalPages, makeHref: (targetPage) => getRouteHref({ ctx, features }, 'getPostsHref', { page: targetPage }) })}
    </div>`;
    scrollViewportToTop(documentRef, windowRef);
    return true;
  };

  hooks.afterIndexRender = (params = {}) => {
    const target = params.container || getRoleElement('main', documentRef);
    try {
      if (target) hydrateCardCovers(target);
      else hydrateCardCovers(getRoleElement('main', documentRef));
    } catch (_) {}
    try {
      hydrateSolsticeCardExcerpts(filterEntriesWithPostHref(params.entries || [], params), { ...params, container: target, document: documentRef });
    } catch (_) {}
    return true;
  };

  hooks.renderSearchResults = ({ container, entries, query, totalPages, page, siteConfig, tagFilter, features, ctx }) => {
    if (!container) container = getRoleElement('main', documentRef);
    if (!container) return false;
    const cards = (entries || []).map(([title, meta]) => {
      const href = meta && meta.location ? getRouteHref({ ctx, features }, 'getPostHref', meta.location) : '';
      return buildCard({ title, meta, translate: t, link: href, siteConfig, features });
    }).join('');
    const summary = query
      ? `${t('ui.searchTab')} · ${escapeHtml(query)}`
      : tagFilter
        ? `${t('ui.tags')} · ${escapeHtml(tagFilter)}`
        : t('ui.searchTab');
    container.innerHTML = `<div class="solstice-index solstice-index--search index">
      <header class="solstice-index__header"><h2>${escapeHtml(summary)}</h2></header>
      <div class="solstice-index__grid">${cards || `<p class="solstice-empty">${t('ui.noResultsTitle')}</p>`}</div>
      ${buildPagination({ page, totalPages, makeHref: (targetPage) => getRouteHref({ ctx, features }, 'getSearchHref', { q: query, tag: tagFilter, page: targetPage }) })}
    </div>`;
    scrollViewportToTop(documentRef, windowRef);
    return true;
  };

  hooks.afterSearchRender = (params = {}) => {
    const target = params.container || getRoleElement('main', documentRef);
    try {
      if (target) hydrateCardCovers(target);
      else hydrateCardCovers(getRoleElement('main', documentRef));
    } catch (_) {}
    try {
      hydrateSolsticeCardExcerpts(filterEntriesWithPostHref(params.entries || [], params), { ...params, container: target, document: documentRef });
    } catch (_) {}
    return true;
  };

  hooks.renderStaticTabLoadingState = ({ containers }) => {
    const main = containers && containers.mainElement ? containers.mainElement : getRoleElement('main', documentRef);
    renderLoader(main, t('ui.loading'));
    return true;
  };

  hooks.renderStaticTabView = ({
    containers,
    title,
    html,
    markdownHtml,
    tocHtml,
    tab,
    translate,
    utilities,
    allowedLocations,
    locationAliasMap,
    postsByLocationTitle,
    postsIndex,
    siteConfig,
    features,
    ctx
  }) => {
    const main = containers && containers.mainElement ? containers.mainElement : getRoleElement('main', documentRef);
    if (!main) return false;
    const heading = title || (tab && tab.title) || '';
    const bodyHtml = markdownHtml != null ? markdownHtml : html;
    renderStaticView(main, heading, bodyHtml);
    scrollViewportToTop(documentRef, windowRef);

    const body = main.querySelector('.solstice-static__body') || main;
    try { if (utilities && typeof utilities.hydratePostImages === 'function') utilities.hydratePostImages(body); } catch (_) {}
    try { if (utilities && typeof utilities.hydratePostVideos === 'function') utilities.hydratePostVideos(body); } catch (_) {}
    try { if (utilities && typeof utilities.applyLazyLoadingIn === 'function') utilities.applyLazyLoadingIn(body); } catch (_) {}
    try { if (utilities && typeof utilities.applyLangHints === 'function') utilities.applyLangHints(body); } catch (_) {}
    try {
      if (utilities && typeof utilities.hydrateInternalLinkCards === 'function') {
        const makeHref = (loc) => getRouteHref({ ctx, features }, 'getPostHref', loc);
        const fetchMarkdown = utilities.fetchMarkdown || (() => Promise.resolve(''));
        utilities.hydrateInternalLinkCards(body, {
          allowedLocations: allowedLocations || new Set(),
          locationAliasMap: locationAliasMap || new Map(),
          postsByLocationTitle: postsByLocationTitle || {},
          postsIndexCache: postsIndex || {},
          siteConfig: siteConfig || {},
          translate: translate || t,
          makeHref,
          fetchMarkdown
        });
      }
    } catch (_) {}

    const toc = containers && containers.tocElement ? containers.tocElement : getRoleElement('toc', documentRef);
    if (toc) {
      if (!featureEnabled({ features }, 'toc')) {
        clearSolsticeToc(toc);
        toc.hidden = true;
      } else if (tocHtml) {
        showToc(toc, tocHtml, heading);
      } else {
        clearSolsticeToc(toc);
        toc.hidden = true;
      }
    }
    return true;
  };

  hooks.handleDocumentClick = ({ event }) => {
    const target = event && event.target;
    if (!target) return false;
    if (target.closest('.solstice-nav__item')) {
      return false;
    }
    return false;
  };

  hooks.handleRouteScroll = ({ document: doc, window: win } = {}) => {
    const scrolled = scrollViewportToTop(doc || documentRef, win || windowRef);
    return scrolled ? true : undefined;
  };

  hooks.handleWindowResize = () => {
    return true;
  };

  hooks.setupThemeControls = () => setupToolsPanel(documentRef, windowRef, activeThemeContext);
  hooks.resetThemeControls = () => resetToolsPanel(documentRef, windowRef, activeThemeContext);
  hooks.updateSearchPlaceholder = (params = {}) => { updateSearchPlaceholder(documentRef, params); return true; };

  hooks.setupResponsiveTabsObserver = () => {
    const header = documentRef.querySelector('.solstice-header');
    if (!header || typeof IntersectionObserver === 'undefined') return false;
    let sentinel = documentRef.querySelector('.solstice-header-sentinel');
    if (!sentinel) {
      sentinel = documentRef.createElement('div');
      sentinel.className = 'solstice-header-sentinel';
      header.parentElement.insertBefore(sentinel, header);
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        header.classList.toggle('is-condensed', !entry.isIntersecting);
      });
    });
    observer.observe(sentinel);
    return true;
  };

  hooks.reflectThemeConfig = ({ siteConfig }) => {
    const root = documentRef.querySelector('.solstice-shell');
    if (root && siteConfig && siteConfig.themePack) {
      root.setAttribute('data-theme-pack', siteConfig.themePack);
    }
    return true;
  };

  hooks.setupFooter = () => {
    const meta = documentRef.querySelector('.solstice-footer__credit');
    if (meta) {
      const year = new Date().getFullYear();
      const siteTitle = localized(currentSiteConfig || {}, 'siteTitle') || 'Press';
      meta.textContent = `© ${year} ${siteTitle}`;
    }
    return true;
  };

  return hooks;
}

export function mount(context = {}) {
  setThemeI18n(context);
  const doc = context.document || defaultDocument;
  const win = (context.document && context.document.defaultView) || defaultWindow;
  const effects = mountHooks(doc, win);
  updateSearchPlaceholder(doc, { context });
  setupToolsPanel(doc, win, context);
  setupDynamicBackground(doc, win);
  const views = {
    post: effects.renderPostView,
    posts: effects.renderIndexView,
    search: effects.renderSearchResults,
    tab: effects.renderStaticTabView,
    error: effects.renderErrorState,
    loading: (params = {}) => (
      params.view === 'tab'
        ? effects.renderStaticTabLoadingState(params)
        : effects.renderPostLoadingState(params)
    )
  };
  return {
    views,
    components: {},
    effects
  };
}

export default {
  mount,
  unmount() {},
  regions: {},
  views: {},
  components: {},
  effects: {}
};
